﻿using System;
using System.Web.UI;

namespace GleamTech.FileUltimateExamples.WebForms.CS.FileManager
{
    public partial class DisplayPage : Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
        }
    }
}